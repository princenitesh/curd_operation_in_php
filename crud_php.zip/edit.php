<?php 
include 'header.php'; 
include 'conn.php'; 

// Check if the 'sid' is passed via the URL
if (isset($_GET['sid'])) {
    $sid = $_GET['sid'];

    // Query the database to fetch the student information for the given ID
    $sql = mysqli_query($conn, "SELECT * FROM studentinformation WHERE id = '$sid'");
    
    if (mysqli_num_rows($sql) > 0) {
        // Fetch the student data
        $row = mysqli_fetch_assoc($sql);
        $sid = $row['id'];
        $name = $row['name'];
        $address = $row['address'];
        $class = $row['class'];
        $phone = $row['phone'];
    } else {
        // If no record is found, redirect to the records page with an error message
        header("Location: all_records.php?message=Record not found");
        exit();
    }
} else {
    // If 'sid' is not passed in the URL, redirect to the records page with an error message
    header("Location: all_records.php?message=No ID provided");
    exit();
}
?>

<div id="main-content">
    <h2>Update Record</h2>
    <form class="post-form" action="updatedata.php" method="post">
        <div class="form-group">
            <label>Name</label>
            <input type="hidden" name="sid" value="<?php echo $sid; ?>" />
            <input type="text" name="sname" value="<?php echo htmlspecialchars($name); ?>" />
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" name="saddress" value="<?php echo htmlspecialchars($address); ?>" />
        </div>
        <div class="form-group">
            <label>Class</label>
            <select name="sclass">
                <option value="" disabled>Select Class</option>
                <option value="1" <?php echo ($class == '1') ? 'selected' : ''; ?>>BCA</option>
                <option value="2" <?php echo ($class == '2') ? 'selected' : ''; ?>>BSC</option>
                <option value="3" <?php echo ($class == '3') ? 'selected' : ''; ?>>B.TECH</option>
            </select>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="sphone" value="<?php echo htmlspecialchars($phone); ?>" />
        </div>
        <input class="submit" type="submit" value="Update" />
    </form>
</div>

</body>
</html>
