<?php
$conn=mysqli_connect("localhost","root","","crud");//this is for only localhost means local server 

//if you work on live server then change with your own username ,password and database 

?>