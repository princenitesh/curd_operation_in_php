<?php
include 'header.php';
include 'conn.php';
?>

<div id="main-content">
    <h2>All Records</h2>
    <table cellpadding="7px" border="1">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Address</th>
                <th>Class</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Prepared statement to fetch all records
            $sql = "SELECT * FROM studentinformation";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    // Get the class value
                    $class = $row['class'];
                    switch ($class) {
                        case 1:
                            $className = 'BCA';
                            break;
                        case 2:
                            $className = 'BSC';
                            break;
                        case 3:
                            $className = 'B.TECH';
                            break;
                        default:
                            $className = 'Unknown';
                    }
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['address']); ?></td>
                        <td><?php echo $className; ?></td>
                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                        <td>
                            <a href="edit.php?sid=<?php echo $row['id']; ?>">Edit</a> | 
                            <a href="delete-inline.php?sid=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                echo "<tr><td colspan='6'>No records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
