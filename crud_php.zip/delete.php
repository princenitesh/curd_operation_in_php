<?php
include 'header.php';
include 'conn.php';

// Check if the form is submitted via POST
if (isset($_POST['submit'])) {
    // Retrieve the student ID to delete
    $sid = $_POST['sid'];

    // Check if the ID is provided
    if (!empty($sid)) {
        // Prepare the DELETE SQL query
        $sql = mysqli_query($conn, "DELETE FROM `studentinformation` WHERE id = '$sid'");

        // Check if the query executed successfully
        if ($sql) {
            // Redirect to index.php or all_records.php after successful deletion
            header("Location: index.php?message=Record deleted successfully");
            exit();
        } else {
            // Show an error message if something went wrong with the query
            echo "<script>alert('Something went wrong. Please check the ID and try again.');</script>";
        }
    } else {
        // Show an error message if no ID is entered
        echo "<script>alert('Please enter a valid ID to delete.');</script>";
    }
}
?>

<div id="main-content">
    <h2>Delete Record</h2>
    <!-- Delete Form -->
    <form class="post-form" action="" method="post">
        <div class="form-group">
            <label for="sid">ID</label>
            <input type="text" name="sid" id="sid" required />
        </div>
        <input class="submit" type="submit" name="submit" value="Delete" />
    </form>
</div>

</div>
</body>
</html>
