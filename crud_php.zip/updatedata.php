<?php
include 'conn.php';  // Include your database connection
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if form data is set and not empty
    if (isset($_POST['sid'], $_POST['sname'], $_POST['saddress'], $_POST['sclass'], $_POST['sphone']) && 
        !empty($_POST['sid']) && !empty($_POST['sname']) && !empty($_POST['saddress']) && 
        !empty($_POST['sclass']) && !empty($_POST['sphone'])) {

        // Sanitize input values to prevent SQL injection and XSS
        $sid = mysqli_real_escape_string($conn, $_POST['sid']);
        $sname = mysqli_real_escape_string($conn, $_POST['sname']);
        $saddress = mysqli_real_escape_string($conn, $_POST['saddress']);
        $sclass = mysqli_real_escape_string($conn, $_POST['sclass']);
        $sphone = mysqli_real_escape_string($conn, $_POST['sphone']);

        // SQL query to update the student information
        $sql = "UPDATE studentinformation SET 
                    name = '$sname', 
                    address = '$saddress', 
                    class = '$sclass', 
                    phone = '$sphone' 
                WHERE id = '$sid'";

        // Execute the query and check if the update was successful
        if (mysqli_query($conn, $sql)) {
            // Redirect back to the records page with a success message
            header("Location: index.php");
            exit();
        } else {
            // If there's an error, display a message
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // If any field is empty, show a message
        echo "All fields are required.";
    }
}
?>
