<?php
error_reporting(E_ALL);
include 'conn.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
	$name = $_POST['sname'];
	$address = $_POST['saddress'];
	$class = $_POST['class'];
	$phone =  $_POST['sphone'];
	
	$sql= mysqli_query($conn,"INSERT INTO `studentinformation`(`name`, `address` , `class`,`phone`) VALUES ('$name','$address','$class','$phone')");
	
	if($sql==true){
		header("Location: index.php");
	}
	
	
}
?>